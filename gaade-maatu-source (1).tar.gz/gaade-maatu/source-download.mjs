const encoder = new TextEncoder();

function tarHeader(name, size) {
  const header = new Uint8Array(512);
  const put = (value, offset) => header.set(encoder.encode(value), offset);
  put('gaade-maatu/' + name, 0);
  put('0000644', 100);
  put('0000000', 108);
  put('0000000', 116);
  put(size.toString(8).padStart(11, '0'), 124);
  put('00000000000', 136);
  header.fill(32, 148, 156);
  put('0', 156);
  put('ustar\0', 257);
  put('00', 263);
  put(header.reduce((sum, byte) => sum + byte, 0).toString(8).padStart(6, '0') + '\0 ', 148);
  return header;
}

export function downloadSource(files, recordings) {
  const entries = Object.entries(files);
  entries.push(['proverb-audio.mjs', 'export default ' + JSON.stringify(recordings, null, 2) + ';\n']);
  const stream = new ReadableStream({
    start(controller) {
      for (const [name, contents] of entries) {
        const data = encoder.encode(contents);
        controller.enqueue(tarHeader(name, data.length));
        controller.enqueue(data);
        const padding = (512 - (data.length % 512)) % 512;
        if (padding) controller.enqueue(new Uint8Array(padding));
      }
      controller.enqueue(new Uint8Array(1024));
      controller.close();
    }
  });
  return new Response(stream.pipeThrough(new CompressionStream('gzip')), {
    headers: {
      'Content-Type': 'application/gzip',
      'Content-Disposition': 'attachment; filename="gaade-maatu-source.tar.gz"',
      'Cache-Control': 'no-cache'
    }
  });
}
