import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';

const modules = [
  'corpus.mjs', 'additional-corpus.mjs', 'additional-situations.mjs', 'rubric-situations.mjs',
  'english.mjs', 'english-meanings.mjs', 'explanation.mjs', 'situation-examples.mjs',
  'search.mjs', 'page.mjs', 'source-download.mjs'
];
const sourceFiles = [
  ...modules, 'build.mjs', 'worker.mjs', 'browser-asr.mjs', 'package.json', '.gitignore', 'README.md',
  'submission/README.md', 'submission/check.mjs', 'submission/consent-template.md', 'submission/export.mjs'
];
await mkdir('dist/server', { recursive: true });
for (const file of [...modules, 'proverb-audio.mjs']) {
  await copyFile(file, 'dist/server/' + file);
}
await copyFile('worker.mjs', 'dist/server/index.js');
const source = Object.fromEntries(await Promise.all(sourceFiles.map(async file =>
  [file, await readFile(file, 'utf8')]
)));
await writeFile('dist/server/download-files.mjs', 'export default ' + JSON.stringify(source) + ';\n');
