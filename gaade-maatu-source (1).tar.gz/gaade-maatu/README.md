# ಗಾದೆ ಮಾತು | Kannada Proverb Finder

[Live app](https://gaadi-maatu-kannada.gableddisco16.chatgpt.site)

Describe a situation in Kannada or English, then press **ಗಾದೆ ಹುಡುಕಿ** to get one Kannada proverb with meanings in both languages, a Kannada explanation, and read-aloud audio.

## Build and check

```sh
npm run build
node submission/check.mjs
```

The web app is a Cloudflare Worker. The build output is `dist/server/index.js`. Browser dictation uses the browser's speech recognition when available. Recording and audio-file transcription use a browser worker and may need an initial model download. The app gives a retry message after 4.5 seconds if transcription has not completed.

## Evaluator dataset

See [the submission README](submission/README.md) for data provenance, review requirements, consent, and the demo. With Node.js and FFmpeg installed, generate the draft CSVs and WAV folder with:

```sh
node submission/export.mjs ./team_XX/problem_02
```

The generated WAV files are synthetic demo readings. The submission still needs verified human readings, contributor consent and regional metadata, and peer review.
