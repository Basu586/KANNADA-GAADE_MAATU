// Each line contains English phrases for the corresponding catalog ID (KP001–KP100).
const phrases = `
hard work|worked hard|studied hard|practice paid off|effort paid off|good grades without studying|reap the rewards|worked tirelessly
live within your means|beyond my means|beyond their means|low income expensive purchase|low salary expensive car|spend more than earn|within budget|earns little but buys a pricey phone on emi|low income expensive phone on installment|small salary expensive phone on emi
kept quiet|stayed silent|said nothing|silence is golden|listened instead of arguing|chose not to speak
wait patiently|waited patiently|patience|did not give up|kept waiting|patiently waited
found another way|found a way despite|where there is a will|determined to find a way|made it happen despite
looks can be deceiving|looked attractive|misleading advertisement|poor quality despite|looked good broke
face the consequences|consequences of his actions|consequences of her actions|punished for breaking|paid for his mistake|faced consequences
seized the opportunity|took the opportunity|grabbed the chance|applied immediately|made the most of the opportunity
lost respect|lost reputation|lost trust|damaged reputation|regain trust
roles reversed|tables turned|power changed hands|asked former subordinates for help
avoided a quarrel by speaking|sensible words prevent quarrels|moderation in eating and speaking
fell through at the last minute|almost got the job|job offer withdrawn|last minute cancellation|offer fell through
guilty person gave himself away|gave herself away|felt guilty and confessed|nobody named him but he panicked
assumes everyone is dishonest|sees everyone as a cheat|judges through prejudice|preconceived notions
dignity of labour|dignity of labor|honest work deserves respect|proud of honest work
put it off|kept postponing|kept delaying|procrastination|left studying until the last minute|put off studying|waited until the last minute
mother proud of her child|mother loves her child|mother is fond of her child
work continued after retirement|carried on after he left|business continued without the boss
blamed the field|blamed the equipment|blamed others for his failure|blamed others for her failure|made excuses for losing|blamed the pitch|blamed the bat|blamed the surface|refused to take responsibility
teach children good habits|habits at a young age|discipline from childhood|teach a child early
slept despite the noise|peace of mind|slept through the noise
learned but humble|knowledge with humility|teacher listened to everyone|humble despite achievements
fact check|verify before sharing|checked whether the video was real|verify a rumour|verify a rumor|checked the facts|verify the news
earn through hard work|work to earn money|earned a living
good company improved habits|good influence of friends|friends encouraged good habits
building a house|organising a wedding|organizing a wedding|learned how hard it was by doing it
lived off savings|spent all savings without working|savings ran out without income|spent without earning
couple made up|husband and wife quarrelled|couple reconciled after an argument
only accepted it when a celebrity said it|trusted because of his reputation|famous person said the same thing
covered up a lie|lied to cover a lie|one lie led to another|more lies to hide the first
truth came out|evidence proved the truth|false accusation exposed
did not boast|didn't boast|talented but modest|real experts do not brag
enjoy the fruits of your labour|enjoy the fruits of your labor|rested after an honest day's work
joke hurt someone|hurt by a joke|one person's fun another person's pain|bullying|mocked a classmate
crushed by debt|high interest loan|debt burden|trapped in debt|too much debt
young athlete won|small in size big in achievement|small person big achievement
advice fell on deaf ears|tried to explain repeatedly|would not listen to advice
months of work destroyed|years of work ruined in seconds|long effort destroyed in a moment
friend helped in trouble|friend in need|friend helped me during a difficult time|friend stood by me|friend came to my aid
helped strangers but neglected family|charitable in public but unkind at home
old habits never changed|never changed his nature|stayed stubborn in old age
bad company|bad influence|fell in with the wrong crowd
blamed the whistleblower|punished for reporting wrongdoing|blamed for exposing fraud
ignored baseless criticism|kept working despite unfair criticism|empty criticism
overreacted to a small problem|used a drastic solution for a small problem
obvious to everyone|plain to see|proof for something obvious
travel and reading|learned by travelling and reading|learned by traveling and reading
had to pay the fine|must face the consequences|could not escape the consequences
clever solution|brains over brawn|outsmarted a stronger opponent|used ingenuity instead of force
looked easy from outside|grass is greener|job looked easier than it was
third person benefited from a fight|third shop gained customers|rivals fought a third gained
guard stole|person entrusted with money stole|protector became the thief
harsh punishment for a small mistake|minor offence severe punishment|minor offense severe punishment
conflicting instructions|contradictory instructions|pulled in opposite directions|disagreed on direction
celebrated too soon|celebrated before the results|counted chickens before they hatched|celebrated before winning
you get what you pay for|cheap product low quality|quality reflects the price
bold outside quiet at home|brave in public timid at home
bought luxuries instead of necessities|spent on decoration while rent unpaid|showed off despite poverty
sat on the fence|refused to take sides|would not commit to a decision
wanted both incompatible things|wanted to save and splurge|wanted to have it both ways
newfound wealth|suddenly rich and showing off|flaunted new wealth
gave authority to a bully|put a bully in charge|gave power to a harmful person
approval granted but staff blocked it|middleman blocked it|clerk blocked approved request
joined the winning side|jumped on the bandwagon|switched sides after victory
made it worse trying to fix it|repair made it worse|broke it while fixing it
another liar backed him up|accomplice vouched for him|wrongdoers supported each other
ignored repeated warnings|warned many times|advice had no effect
wasted someone else's money|wasted company money|spent public money recklessly
understood from a hint|corrected the mistake after a small hint
trouble came on top of trouble|one setback after another|lost job and repair bill|when it rains it pours
only one knew a little|little knowledge looked like expertise|least inexperienced became leader
all talk no action|talked more than he worked|big speech no work
did not practice what he preached|did not practise what she preached|practice what you preach|hypocrisy|preached one thing did another
caused damage without supervision|unchecked behaviour caused damage|unchecked behavior caused damage
huge effort tiny result|months of work for a small result|much effort little reward
time for study and play|played instead of studying|set aside time for each task
denied losing|refused to admit defeat|lost but claimed victory
fox guarding the henhouse|put the thief in charge of security|gave the thief the keys
effects remained after the problem ended|old habit lingered|suspicion stayed after the dispute
every family has problems|no family is perfect|everyone has difficulties|neighbour mocks your problems his house has the same|neighbor mocks my problems but has the same|mocked our problems but had the same at home
found fault in everything|disliked her and criticised everything|looked for faults in someone he disliked
cannot take back words|words spoken in anger|regretted what he said|regretted what she said
too much of a good thing|exercised too much|overdoing it|excess caused harm
greed|lost everything chasing profit|too greedy|risked everything for more profit|wanted more and lost it all
overlooked local talent|ignored talent close to home|hired an outsider despite local expertise
work is worship|treated work as worship|worked with dedication and honesty
fought over something free|needless competition for something everyone can get
missed an opportunity by not applying|let the opportunity slip|failed to apply in time|missed the chance through carelessness
take care of your own house first|neglected own responsibilities|gave advice while ignoring own problems
defused an argument by speaking calmly|calmed an angry customer|calm words prevented a fight
hurtful words left a lasting wound|still hurt by an insult|never forgot the hurtful words
saving money|saved money|save money|put aside money|set aside a little|saved a little|little by little|small amounts add up|saved a small amount|saved a few rupees|saved a few coins
thought of a solution too late|advice came too late|realised what to do too late|realized what to do too late
good initiative faced obstacles|faced obstacles starting a library|good deed encountered resistance
asked for unnecessary permission|permission for a public park
duplicated work|collected the same information again|repeated work already done
travel and learn a language|learned the local language while traveling|learned the local language while travelling
wrong method|expected results without preparation|needed the right method
gave a scammer confidential information|gave someone the means to harm him|handed over my password to a scammer
kept raising false alarms|cried wolf|false alarms nobody believed the real one|false alarm
`.trim().split('\n').map(line => line.split('|').map(tokens));

function tokens(text) {
  return text.toLowerCase().match(/[a-z]+/g) ?? [];
}

const common = new Set('a an the i he she it they we of on at in and but to for is are was were be by with his her my their your this that than as not so how when could would did had have has'.split(' '));
const normalize = word => word.replace(/(?:ing|ed|s)$/u, '') || word;

function terms(input) {
  return new Set(input.filter(word => word.length > 2 && !common.has(word)).map(normalize));
}

export function englishScores(situation) {
  const input = tokens(situation);
  if (!input.length) return new Map();
  const sequence = ' ' + input.join(' ') + ' ';
  const query = terms(input);
  const scores = new Map();
  for (const [index, alternatives] of phrases.entries()) {
    let best = 0;
    for (const phrase of alternatives) {
      const expected = terms(phrase);
      if (sequence.includes(' ' + phrase.join(' ') + ' ')) {
        best = Math.max(best, phrase.length === 1 ? 4.5 : 6 + expected.size);
        continue;
      }
      const shared = [...expected].filter(term => query.has(term)).length;
      if (shared >= 2 && shared / expected.size >= 0.6) {
        best = Math.max(best, 2 + 5 * shared / expected.size + 0.35 * shared);
      }
    }
    if (best) scores.set('KP' + String(index + 1).padStart(3, '0'), best);
  }
  const latePreparation = /\b(?:skip(?:ped)?|never|did(?:n t| not))\b.*\bstud(?:y(?:ing)?|ied)\b.*\b(?:exam|test)\b/.test(input.join(' '));
  const lastMinute = /\b(?:before|tomorrow|panic\w*|last minute)\b/.test(input.join(' '));
  if (latePreparation && lastMinute) scores.set('P236', 16);
  return scores;
}
