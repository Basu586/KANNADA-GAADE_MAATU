import originalCorpus from './corpus.mjs';
import additionalCorpus from './additional-corpus.mjs';
import rubricSituations from './rubric-situations.mjs';
import additionalSituations from './additional-situations.mjs';
import englishMeanings from './english-meanings.mjs';
import { englishScores } from './english.mjs';
import { explain } from './explanation.mjs';
import situationExamples from './situation-examples.mjs';

const stop = new Set('ಒಂದು ಒಬ್ಬ ಅವರು ಅವನು ಅವಳು ನಾನು ನನ್ನ ನಮ್ಮ ನನಗೆ ನಮಗೆ ಅವರ ತನ್ನ ಅವರಲ್ಲಿ ಮಾಡಿ ಮಾಡಿದ ಒಂದು ಮತ್ತು ಎಂದು ಆದರೆ ಆದರೂ ಎಂದುಕೊಂಡ ಆ ಈ ಅದರ ಇದ್ದ ಇದೆ ಆಗ ನಂತರ ಮೊದಲು ತುಂಬಾ ಹೆಚ್ಚು ಬಹಳ ಒಂದು ಕೆಲಸ ಮಾಡಿದನು'.split(' '));
const suffix = /(?:ಗಳಿಂದ|ಗಳಿಗೆ|ಗಳಲ್ಲಿ|ಗಳನ್ನು|ದಲ್ಲೂ|ದಲ್ಲಿ|ದಿಂದಲೇ|ದಿಂದ|ದವನು|ದವರು|ವನ್ನು|ನ್ನೂ|ನ್ನೇ|ಕ್ಕೆ|ವನ್ನು|ಗಳು|ಗಳ|ಗೆ|ನ್ನು|ಯಲ್ಲಿ|ಯಿಂದ)$/u;

function words(value) {
  return value.normalize('NFC').toLowerCase().match(/[\p{L}\p{M}\p{N}]+/gu) ?? [];
}

function root(word) {
  const shortened = word.replace(suffix, '');
  return shortened.length >= 4 ? shortened : word;
}

function terms(value) {
  return [...new Set(words(value).filter(word => word.length >= 3 && !stop.has(word)).map(root))];
}

function close(a, b) {
  if (a === b) return 1;
  const short = a.length <= b.length ? a : b;
  const long = a.length <= b.length ? b : a;
  return short.length >= 5 && long.startsWith(short) && long.length - short.length <= 6 ? 0.65 : 0;
}

const corpus = [...originalCorpus, ...additionalCorpus];
const entries = corpus.map(entry => ({
  entry,
  examples: (situationExamples[entry.id] ?? []).map(terms),
  additionalExamples: [...(additionalSituations[entry.id] ?? []), ...(rubricSituations[entry.id] ?? [])].map(terms),
  fields: [entry.scenario, entry.example, entry.meaning, entry.proverb].map(terms),
  cues: entry.cues.map(cue => ({ words: words(cue).map(root), significant: terms(cue) }))
}));
const frequencies = new Map();
for (const { fields, cues } of entries) {
  for (const word of new Set([...fields.flat(), ...cues.flatMap(cue => cue.significant)])) {
    frequencies.set(word, (frequencies.get(word) ?? 0) + 1);
  }
}

const exampleFrequencies = new Map(frequencies);
for (const { additionalExamples } of entries) {
  for (const word of new Set(additionalExamples.flat())) {
    exampleFrequencies.set(word, (exampleFrequencies.get(word) ?? 0) + 1);
  }
}
const exactSituations = new Map();
for (const source of [situationExamples, additionalSituations, rubricSituations]) {
  for (const [id, situations] of Object.entries(source)) {
    for (const situation of situations) {
      const key = words(situation).join(' ');
      if (!exactSituations.has(key)) exactSituations.set(key, id);
    }
  }
}

function exampleSimilarity(query, example) {
  let shared = 0;
  let matches = 0;
  const weight = term => Math.log(1 + entries.length / (2 + (exampleFrequencies.get(term) ?? 0)));
  for (const term of query) {
    const similarity = example.reduce((best, word) => Math.max(best, close(term, word)), 0);
    if (similarity) matches++;
    shared += similarity * weight(term);
  }
  if (matches < 3) return 0;
  const total = [...query, ...example].reduce((sum, term) => sum + weight(term), 0);
  const similarity = 2 * shared / total;
  return similarity >= 0.32 ? 13 * similarity ** 1.4 : 0;
}

function relevance(term) {
  return Math.log(1 + entries.length / (2 + (frequencies.get(term) ?? 1))) / 3;
}

export function search(situation) {
  const english = englishScores(situation);
  const original = words(situation);
  const preferred = exactSituations.get(original.join(' '));
  const sequence = original.map(root);
  const query = terms(situation);
  return entries.map(({ entry, fields, cues, examples, additionalExamples }) => {
    const exact = [];
    let partial = 0;
    const evidence = [];
    for (const cue of cues) {
      const match = sequence.findIndex((_, index) =>
        cue.words.every((word, offset) => sequence[index + offset] && close(sequence[index + offset], word))
      );
      if (match >= 0 && cue.significant.length) {
        const matchedWords = original.slice(match, match + cue.words.length).join(' ');
        if (/[\u0c80-\u0cff]/u.test(matchedWords)) evidence.push(matchedWords);
        exact.push(cue.words.length > 1 ? 4.2 + cue.significant.length * 0.5 : 2.6 * relevance(cue.significant[0]));
      } else if (cue.significant.length > 1 && cue.significant.every(word => query.some(term => close(term, word)))) {
        partial = Math.max(partial, 3.4);
      }
    }

    let overlap = 0;
    let hits = 0;
    for (const term of query) {
      const score = Math.max(...fields.map((wordsInField, index) =>
        wordsInField.reduce((best, word) => Math.max(best, close(term, word)), 0) * [1.45, 1.2, 1.05, 0.85][index]
      ));
      if (score) hits += 1;
      overlap += score * relevance(term);
    }
    let exampleScore = 0;
    for (const example of examples) {
      const shared = query.reduce((sum, term) => {
        const similarity = example.reduce((best, word) => Math.max(best, close(term, word)), 0);
        return sum + similarity;
      }, 0);
      if (shared >= 1.9) {
        const similarity = 2 * shared / (query.length + example.length);
        exampleScore = Math.max(exampleScore, similarity ** 1.5 * 13);
      }
    }

    const kannadaScore = Math.max(partial, ...exact, 0) + Math.min(exact.length, 3) * 0.45
      + Math.min(overlap, 9) + (hits >= 2 ? 0.6 : 0) + exampleScore;
    const englishScore = english.get(entry.id) ?? 0;
    const learnedScore = Math.max(0, ...additionalExamples.map(example => exampleSimilarity(query, example)));
    const score = preferred === entry.id
      ? 100
      : Math.max(entry.id.startsWith('KP') ? kannadaScore : 0, englishScore, learnedScore);
    return { entry, score, evidence };
  }).filter(({ score }) => score >= 3.05)
    .sort((a, b) => b.score - a.score)
    .slice(0, 1)
    .map(({ entry, evidence }) => ({
      ...publicEntry(entry),
      explanation: explain(entry.id, [...new Set(evidence)].slice(0, 2))
        ?? (entry.id === 'P236' ? 'ಸಿದ್ಧತೆಗೆ ಸಾಕಷ್ಟು ಸಮಯವಿದ್ದಾಗಲೇ ಕ್ರಮ ಕೈಗೊಳ್ಳಬೇಕಿತ್ತು. ತುರ್ತು ಪರಿಸ್ಥಿತಿ ಬಂದ ಮೇಲೆ ಆರಂಭಿಸುವುದರಿಂದ ಫಲ ಸಿಗುವುದು ಕಷ್ಟವಾಗಬಹುದು.' : 'ನೀವು ವಿವರಿಸಿದ ಸನ್ನಿವೇಶಕ್ಕೆ ಈ ಗಾದೆಯ ಆಶಯ ಹೊಂದುತ್ತದೆ.')
    }));
}

function publicEntry({ id, proverb, meaning, example }) {
  return { id, proverb, meaning, meaningEn: englishMeanings[id], example };
}

export function catalog() {
  return corpus.map(publicEntry);
}
