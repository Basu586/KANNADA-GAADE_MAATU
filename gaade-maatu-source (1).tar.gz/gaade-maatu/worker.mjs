import { catalog, search } from './search.mjs';
import { downloadSource } from './source-download.mjs';
import sourceFiles from './download-files.mjs';
import recordings from './proverb-audio.mjs';
import { page } from './page.mjs';

export default {
  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (request.method === 'GET' && path === '/downloads/source.tar.gz') return downloadSource(sourceFiles, recordings);
    if (request.method === 'GET' && path === '/voice-worker.mjs') {
      return new Response(sourceFiles['browser-asr.mjs'], { headers: { 'Content-Type': 'text/javascript; charset=utf-8' } });
    }
    if (path === '/api/search' && request.method === 'POST') {
      const body = await request.json().catch(() => null);
      if (typeof body?.situation !== 'string' || !body.situation.trim() || body.situation.length > 1000) {
        return Response.json({ error: 'ದಯವಿಟ್ಟು ಸನ್ನಿವೇಶವನ್ನು ಸಂಕ್ಷಿಪ್ತವಾಗಿ ಬರೆಯಿರಿ.' }, { status: 400 });
      }
      return Response.json({ results: search(body.situation) });
    }
    const clip = /^\/audio\/((?:KP|P)[0-9]{3})\.mp3$/.exec(path);
    if (clip && request.method === 'GET' && recordings[clip[1]]) {
      const audio = Uint8Array.from(atob(recordings[clip[1]]), character => character.charCodeAt(0));
      return new Response(audio, { headers: { 'Content-Type': 'audio/mpeg', 'Cache-Control': 'public, max-age=86400' } });
    }
    if (path === '/api/catalog' && request.method === 'GET') return Response.json(catalog());
    if (path === '/' && request.method === 'GET') {
      return new Response(page, { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    }
    return new Response('ಪುಟ ಸಿಗಲಿಲ್ಲ', { status: 404, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
  }
};
