export const page = `<!doctype html>
<html lang="kn">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ಗಾದೆ ಮಾತು</title>
<meta name="description" content="ನಿಮ್ಮ ಸನ್ನಿವೇಶಕ್ಕೆ ತಕ್ಕ ಕನ್ನಡ ಗಾದೆ ಹುಡುಕಿ.">
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Kannada:wght@400;500;600;700;800&display=swap');
:root{color-scheme:light;--ink:#351d38;--paper:#fff6eb;--gold:#ffc866;--muted:#635064;--line:#ead9e7}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.75 "Noto Sans Kannada",sans-serif}
header{background:#351635;color:#fff9f3;border-bottom:1px solid #ffffff28}nav{max-width:1040px;margin:auto;padding:15px 24px;display:flex;align-items:center;justify-content:space-between;gap:12px}a{color:inherit;text-decoration:none}nav a:hover{text-decoration:underline}.brand{display:flex;align-items:center;gap:11px;font-size:21px;font-weight:800}.mark{display:grid;place-items:center;background:var(--gold);color:#351635;border-radius:10px;width:37px;height:37px;box-shadow:0 0 0 3px #ffc86633}
.hero{background:radial-gradient(ellipse at 85% 30%,#913e69 0%,transparent 50%),linear-gradient(115deg,#412044,#622854);color:#fff9f3;position:relative;overflow:hidden}.hero:after{content:"“";position:absolute;right:6%;top:-140px;color:#ffc86624;font:590px Georgia;pointer-events:none}.hero-inner{max-width:1040px;margin:auto;padding:48px 24px 75px;position:relative;z-index:1}.hero h1{font-size:clamp(32px,6vw,61px);line-height:1.45;margin:0 0 10px;letter-spacing:-.025em}.hero em{color:#ffce78;font-style:normal}.hero p{margin:0;color:#f5e3f4}
main{max-width:1040px;margin:-36px auto 0;padding:0 24px 48px;position:relative;z-index:2}
.layout{display:grid;grid-template-columns:minmax(0,1.65fr) minmax(0,1fr);gap:20px;align-items:start}.panel,article{background:#fffcff;border:1px solid var(--line);border-radius:18px;padding:24px;box-shadow:0 8px 20px #51204b1a}.panel h2,h2{font-size:23px;line-height:1.55;margin:0 0 9px}.panel p{margin:0 0 14px;color:var(--muted)}
textarea{display:block;width:100%;min-height:140px;resize:vertical;background:#fbf3fc;border:1px solid #aa91ab;border-radius:12px;padding:14px;font:inherit;color:inherit}textarea::placeholder{color:#705a73}button{font:inherit;cursor:pointer}button:disabled{opacity:.6;cursor:wait}:focus-visible{outline:3px solid #86549b;outline-offset:3px}
.voice-tools{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:12px 0}.voice-button,.voice-tools select{font:inherit;background:#e7f7f3;color:#174c44;border:1px solid #9fc9c0;border-radius:10px;padding:8px 12px}.voice-button[aria-pressed="true"]{background:#823350;color:white}.voice-status{font-size:.9rem;margin:0;color:var(--muted)}.voice-status:empty{display:none}.voice-tools [hidden],#voice-meter[hidden],#voice-review[hidden]{display:none}.voice-button{min-height:44px}.voice-input-primary{font-weight:700}.voice-meter{display:flex;align-items:center;gap:8px;margin:8px 0}.voice-meter meter{width:min(180px,48vw)}.voice-review{display:grid;gap:8px;margin:8px 0}.voice-review audio,.proverb-player{width:100%;max-width:400px}.proverb-player{display:block;margin-top:8px}#voice-standalone{text-decoration:underline;font-size:.9rem}.playback{margin-top:14px}.action{display:flex;justify-content:flex-end;margin-top:15px}.primary{background:#08756b;color:white;border:0;border-radius:10px;padding:10px 19px;font-weight:700}.primary:hover{background:#065d55}
.examples{display:grid;gap:9px}.sample{display:flex;align-items:center;justify-content:space-between;text-align:left;background:#fff0dc;color:var(--ink);border:1px solid #eed1aa;border-radius:10px;padding:9px 12px;gap:12px}.sample:hover{background:#ffe5c0}.sample:nth-child(2){background:#e7f7f3;border-color:#beded7}.sample:nth-child(2):hover{background:#d5f0e9}.sample:nth-child(3){background:#f3e8fa;border-color:#e0c8ee}.sample:nth-child(3):hover{background:#ead8f5}.sample span{flex-shrink:0;color:#6f4267}
#results{margin-top:22px;scroll-margin-top:18px}.result-list,.collection{display:grid;gap:12px}.result-list article:first-child{border-color:#a3648f;background:linear-gradient(125deg,#fff2e1,#fffcff 65%)}.quote{font-size:clamp(20px,4vw,30px);line-height:1.6;margin:4px 0 12px}.details{margin:0}.details dt{font-weight:700}.details dd{margin:0;color:var(--muted)}.details dt:not(:first-child){margin-top:12px}#status{margin:8px 0;color:var(--muted)}#status:empty{display:none}
#catalog{margin:27px 0 0;border-top:1px solid var(--line);padding-top:16px;scroll-margin-top:16px}.catalog-search{display:grid;gap:5px;max-width:420px;margin-top:12px}.catalog-count{margin:10px 0 0;color:var(--muted)}.catalog-search[hidden]{display:none}.catalog-search input{width:100%;padding:8px 12px;border:1px solid #aa91ab;border-radius:10px;background:#fffcff;color:inherit;font:inherit}summary{cursor:pointer;font-size:19px;font-weight:700}.collection{grid-template-columns:repeat(auto-fit,minmax(min(270px,100%),1fr));margin-top:14px}.collection article{padding:17px}.collection .quote{font-size:19px}footer{background:#f8eaf4;border-top:1px solid var(--line);text-align:center;color:var(--muted);padding:14px 24px}
@media(max-width:700px){.layout{grid-template-columns:1fr}.hero-inner{padding-top:34px}.panel,article{padding:18px}main,nav,.hero-inner{padding-left:16px;padding-right:16px}.primary{width:100%}}
</style>
</head>
<body>
<header><nav aria-label="ಮುಖ್ಯ ಸಂಚರಣೆ"><a class="brand" href="/" aria-label="ಗಾದೆ ಮಾತು ಮುಖಪುಟ"><span class="mark" aria-hidden="true">ಗಾ</span> ಗಾದೆ ಮಾತು</a><a id="catalog-link" href="#catalog">ಗಾದೆಗಳ ಸಂಗ್ರಹ <span aria-hidden="true">↗</span></a></nav></header>
<section class="hero"><div class="hero-inner"><h1>ನಿಮ್ಮ ಸನ್ನಿವೇಶಕ್ಕೆ<br><em>ಒಂದು ಗಾದೆ ಹುಡುಕಿ</em></h1><p>ಏನಾಯಿತು ಎಂದು ಕನ್ನಡದಲ್ಲಿ ಅಥವಾ ಇಂಗ್ಲಿಷ್‌ನಲ್ಲಿ ಬರೆಯಿರಿ. ಅದಕ್ಕೆ ಹೊಂದುವ ಗಾದೆ ಮತ್ತು ಅದರ ಅರ್ಥವನ್ನು ನೋಡಿ.</p></div></section>
<main>
<div class="layout">
<form class="panel" id="search-form">
<h2><label for="situation">ನಿಮ್ಮ ಸನ್ನಿವೇಶ</label></h2>
<p id="hint">ಕನ್ನಡ ಅಥವಾ ಇಂಗ್ಲಿಷ್‌ನಲ್ಲಿ ಸನ್ನಿವೇಶವನ್ನು ಹೇಳಿ ಅಥವಾ ಬರೆಯಿರಿ. ನೇರ ಧ್ವನಿಗಾಗಿ ಬ್ರೌಸರ್‌ನ ಮಾತು ಗುರುತಿಸುವ ಸೇವೆ ಬಳಕೆಯಾಗಬಹುದು. ನಂತರ ಗಾದೆ ಹುಡುಕಿ ಗುಂಡಿಯನ್ನು ಒತ್ತಿರಿ.</p>
<div class="voice-tools">
<select id="voice-language" aria-label="ಮಾತನಾಡುವ ಭಾಷೆ"><option value="kn-IN">ಕನ್ನಡ</option><option value="en-IN">ಇಂಗ್ಲಿಷ್</option></select>
<button type="button" id="voice-input" class="voice-button voice-input-primary" aria-pressed="false"><span aria-hidden="true">🎙</span> <span id="voice-label">ಸನ್ನಿವೇಶ ಹೇಳಿ</span></button>
<button type="button" id="voice-record" class="voice-button" hidden>ಧ್ವನಿ ದಾಖಲಿಸಿ</button>
<button type="button" id="voice-file-button" class="voice-button">ಧ್ವನಿ ಕಡತ ಆಯ್ಕೆಮಾಡಿ</button>
<input id="voice-file" type="file" accept="audio/*" hidden>
</div>
<p id="voice-status" class="voice-status" role="status"></p>
<div id="voice-meter" class="voice-meter" hidden><span aria-hidden="true">🔴</span><label for="mic-level">ಧ್ವನಿ ಮಟ್ಟ</label><meter id="mic-level" min="0" max="100" value="0"></meter></div>
<div id="voice-review" class="voice-review" hidden><audio id="mic-preview" controls preload="none" aria-label="ನಿಮ್ಮ ಧ್ವನಿಯನ್ನು ಕೇಳಿ"></audio><button type="button" id="voice-retry" class="voice-button" hidden>ಮತ್ತೆ ಬರಹಕ್ಕೆ ಪರಿವರ್ತಿಸಿ</button></div>
<a id="voice-standalone" href="/" target="_blank" rel="noopener" hidden>ಮೈಕ್ರೊಫೋನ್‌ಗಾಗಿ ಹೊಸ ಟ್ಯಾಬ್‌ನಲ್ಲಿ ತೆರೆಯಿರಿ ↗</a>
<textarea id="situation" dir="auto" aria-describedby="hint" required maxlength="1000" placeholder="ಉದಾಹರಣೆಗೆ, ನಾನು ಪ್ರತಿದಿನ ಸ್ವಲ್ಪ ಹಣ ಉಳಿಸಿ ಕೊನೆಗೆ ಸೈಕಲ್ ಖರೀದಿಸಿದೆ."></textarea>
<div class="action"><button id="search-button" type="button" class="primary">ಗಾದೆ ಹುಡುಕಿ <span aria-hidden="true">→</span></button></div>
</form>
<aside class="panel"><h2>ಈ ಸನ್ನಿವೇಶಗಳನ್ನು ಪ್ರಯತ್ನಿಸಿ</h2><div class="examples">
<button type="button" class="sample" data-situation="ನಾನು ಪ್ರತಿದಿನ ಸ್ವಲ್ಪ ಹಣ ಉಳಿಸಿ ಕೊನೆಗೆ ಸೈಕಲ್ ಖರೀದಿಸಿದೆ.">ಸ್ವಲ್ಪ ಸ್ವಲ್ಪವಾಗಿ ಹಣ ಉಳಿಸಿದ್ದು <span aria-hidden="true">↗</span></button>
<button type="button" class="sample" data-situation="ತಂಡದ ಇಬ್ಬರು ಮುಖ್ಯಸ್ಥರು ವಿರುದ್ಧ ಸೂಚನೆ ಕೊಟ್ಟದ್ದರಿಂದ ಕೆಲಸ ಮುಂದೆ ಸಾಗಲಿಲ್ಲ.">ತಂಡದಲ್ಲಿ ಹೊಂದಾಣಿಕೆಯಿಲ್ಲದಿರುವುದು <span aria-hidden="true">↗</span></button>
<button type="button" class="sample" data-situation="ನನ್ನ ಸಂಬಳ ಕಡಿಮೆ. ಆದರೂ ದುಬಾರಿ ಕಾರು ಕೊಳ್ಳಲು ದೊಡ್ಡ ಸಾಲ ಮಾಡಬೇಕೆಂದಿದ್ದೇನೆ.">ಆದಾಯ ಮೀರಿ ಖರ್ಚು ಮಾಡುವುದು <span aria-hidden="true">↗</span></button>
<button type="button" class="sample" data-situation="ರವಿಯು ಇಡೀ ಅವಧಿಯಲ್ಲಿ ಓದಲಿಲ್ಲ. ಪರೀಕ್ಷೆಗೆ ಒಂದು ದಿನ ಉಳಿದಾಗ ಗಾಬರಿಯಿಂದ ಪುಸ್ತಕ ತೆರೆದನು.">ಪರೀಕ್ಷೆಗೆ ತಡವಾಗಿ ಓದಲು ಶುರುಮಾಡಿದ್ದು <span aria-hidden="true">↗</span></button>
<button type="button" class="sample" data-situation="ಪಕ್ಕದ ಮನೆಯವರು ನಮ್ಮ ಹಣದ ತೊಂದರೆಯನ್ನು ಹಾಸ್ಯ ಮಾಡಿದರು. ಅವರ ಮನೆಯಲ್ಲೂ ಅದೇ ಸಮಸ್ಯೆ ಇತ್ತು.">ನೆರೆಮನೆಯಲ್ಲೂ ಅದೇ ತೊಂದರೆ <span aria-hidden="true">↗</span></button>
<button type="button" class="sample" data-situation="I saved a little money every day until I could buy a bicycle.">ಇಂಗ್ಲಿಷ್ ಉದಾಹರಣೆ <span aria-hidden="true">↗</span></button>
</div></aside>
</div>
<section id="results" aria-label="ಹುಡುಕಾಟದ ಫಲಿತಾಂಶಗಳು"><p id="status" role="status"></p><h2 id="result-heading" tabindex="-1" hidden>ಸನ್ನಿವೇಶಕ್ಕೆ ಹೊಂದುವ ಗಾದೆ</h2><div class="result-list" id="matches"></div></section>
<details id="catalog"><summary id="catalog-summary">ಗಾದೆಗಳ ಸಂಗ್ರಹ</summary><p id="catalog-count" class="catalog-count" role="status" hidden></p><label class="catalog-search" id="catalog-search" hidden>ಸಂಗ್ರಹದಲ್ಲಿ ಹುಡುಕಿ<input id="catalog-filter" type="search" placeholder="ಗಾದೆ ಅಥವಾ ಅದರ ಅರ್ಥ"></label><div id="collection" class="collection" aria-live="polite"></div></details>
</main><footer>ಗಾದೆ ಮಾತು · ಕನ್ನಡ ಗಾದೆಗಳ ಸಂಗ್ರಹ · <a href="/downloads/source.tar.gz" download>ಮೂಲ ಕೋಡ್ ಡೌನ್‌ಲೋಡ್ ↓</a></footer>
<script>
const form = document.querySelector('#search-form');
const situation = document.querySelector('#situation');
const submit = document.querySelector('#search-button');
const matches = document.querySelector('#matches');
const status = document.querySelector('#status');
const heading = document.querySelector('#result-heading');
const catalog = document.querySelector('#catalog');
const collection = document.querySelector('#collection');
const microphone = document.querySelector('#voice-input');
const voiceLanguage = document.querySelector('#voice-language');
const voiceLabel = document.querySelector('#voice-label');
const voiceStatus = document.querySelector('#voice-status');
const standalone = document.querySelector('#voice-standalone');
const embedded = window.top !== window.self;
if (embedded) standalone.hidden = false;
const voiceFile = document.querySelector('#voice-file');
const voiceFileButton = document.querySelector('#voice-file-button');
const voiceMeter = document.querySelector('#voice-meter');
const micLevel = document.querySelector('#mic-level');
const review = document.querySelector('#voice-review');
const micPreview = document.querySelector('#mic-preview');
const retryVoice = document.querySelector('#voice-retry');
let lastAudio;
let recording = null;
let requested = false;
let transcribing = null;
let voiceAttempt = 0;
let dictated = false;
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recordButton = document.querySelector('#voice-record');
recordButton.hidden = !SpeechRecognition;
let dictation;
let voiceWorker;
let workerRequest = 0;
const voiceWait = 4500;
const timeoutMessage = 'ಧ್ವನಿ ಬರಹಕ್ಕೆ ಬದಲಾಗಲು ಹೆಚ್ಚು ಸಮಯ ಬೇಕಾಗಿದೆ. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ ಅಥವಾ ಸನ್ನಿವೇಶವನ್ನು ಬರೆಯಿರಿ.';
let playing;

function updateVoiceControls() {
  microphone.disabled = requested || Boolean(transcribing || (SpeechRecognition && recording));
  recordButton.disabled = requested || Boolean(transcribing || dictation);
  recordButton.textContent = recording ? 'ಧ್ವನಿ ದಾಖಲಿಸುವುದನ್ನು ಮುಗಿಸಿ' : 'ಧ್ವನಿ ದಾಖಲಿಸಿ';
  microphone.setAttribute('aria-pressed', String(Boolean(dictation || (!SpeechRecognition && recording))));
  voiceLanguage.disabled = requested || Boolean(transcribing || recording || dictation);
  voiceFileButton.disabled = voiceLanguage.disabled;
  retryVoice.disabled = voiceLanguage.disabled;
  voiceLabel.textContent = dictation ? 'ಮಾತು ಮುಗಿಸಿ' : recording && !SpeechRecognition ? 'ಧ್ವನಿ ದಾಖಲಿಸುವುದನ್ನು ಮುಗಿಸಿ' : 'ಸನ್ನಿವೇಶ ಹೇಳಿ';
}

function monitorRecording(session) {
  voiceMeter.hidden = false;
  micLevel.value = 0;
  try {
    const Audio = window.AudioContext || window.webkitAudioContext;
    const context = new Audio();
    session.context = context;
    const source = context.createMediaStreamSource(session.stream);
    const analyser = context.createAnalyser();
    source.connect(analyser);
    const frame = new Uint8Array(analyser.fftSize);
    session.meterTimer = setInterval(() => {
      analyser.getByteTimeDomainData(frame);
      const peak = frame.reduce((value, sample) => Math.max(value, Math.abs(sample - 128)), 0);
      micLevel.value = Math.min(100, peak * 3);
    }, 100);
    void context.resume().catch(() => {});
  } catch {
    // Recording can continue where the browser blocks the optional meter.
  }
}

function releaseRecording(session) {
  clearTimeout(session.timer);
  clearInterval(session.meterTimer);
  if (session.context) void session.context.close().catch(() => {});
  voiceMeter.hidden = true;
  session.stream.getTracks().forEach(track => track.stop());
}

function stopRecording() {
  voiceAttempt++;
  if (dictation) {
    const active = dictation;
    dictation = null;
    clearTimeout(active.timer);
    clearTimeout(active.limit);
    active.recognition.abort();
  }
  const current = recording;
  recording = null;
  requested = false;
  transcribing?.abort();
  transcribing = null;
  if (current) releaseRecording(current);
  updateVoiceControls();
}

function recognizeSamples(audio, language, signal) {
  if (signal.aborted) return Promise.reject(signal.reason);
  voiceWorker ??= new Worker('/voice-worker.mjs', { type: 'module' });
  const worker = voiceWorker;
  const id = ++workerRequest;
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      worker.removeEventListener('message', message);
      worker.removeEventListener('error', failed);
      signal.removeEventListener('abort', canceled);
    };
    const message = ({ data }) => {
      if (data.id !== id) return;
      cleanup();
      if (data.error) reject(new Error('Transcription failed'));
      else resolve(data.text);
    };
    const failed = () => {
      cleanup();
      if (voiceWorker === worker) voiceWorker = undefined;
      worker.terminate();
      reject(new Error('Voice worker failed'));
    };
    const canceled = () => {
      cleanup();
      reject(signal.reason);
    };
    worker.addEventListener('message', message);
    worker.addEventListener('error', failed);
    signal.addEventListener('abort', canceled, { once: true });
    worker.postMessage({ id, language, audio }, [audio.buffer]);
  });
}

async function transcribe(blob, language, signal) {
  const Audio = window.AudioContext || window.webkitAudioContext;
  const OfflineAudio = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  const context = new Audio();
  let decoded;
  try {
    decoded = await context.decodeAudioData(await blob.arrayBuffer());
  } finally {
    await context.close();
  }
  const rate = 16000;
  const offline = new OfflineAudio(1, Math.ceil(Math.min(decoded.duration, 30) * rate), rate);
  const source = offline.createBufferSource();
  source.buffer = decoded;
  source.connect(offline.destination);
  source.start();
  const audio = (await offline.startRendering()).getChannelData(0);
  if (!audio.some(sample => Math.abs(sample) > 0.005)) return '';
  return recognizeSamples(audio, language, signal);
}

async function acceptAudio(blob, language, attempt) {
  if (blob.size && lastAudio?.blob !== blob) {
    if (lastAudio) URL.revokeObjectURL(lastAudio.url);
    lastAudio = { blob, url: URL.createObjectURL(blob) };
    micPreview.src = lastAudio.url;
    review.hidden = false;
  }
  retryVoice.hidden = true;
  voiceStatus.textContent = 'ಧ್ವನಿಯನ್ನು ಬರಹಕ್ಕೆ ಪರಿವರ್ತಿಸಲಾಗುತ್ತಿದೆ. ಮೊದಲ ಬಾರಿ ಸ್ವಲ್ಪ ಸಮಯ ಹಿಡಿಯಬಹುದು…';
  const task = new AbortController();
  const timer = setTimeout(() => task.abort(), voiceWait);
  transcribing = task;
  updateVoiceControls();
  try {
    const deadline = new Promise((_, reject) => {
      task.signal.addEventListener('abort', () => reject(task.signal.reason), { once: true });
    });
    const text = blob.size ? await Promise.race([transcribe(blob, language, task.signal), deadline]) : '';
    if (attempt !== voiceAttempt) return;
    if (!text) {
      voiceStatus.textContent = 'ಮಾತು ಕೇಳಿಸಲಿಲ್ಲ. ದಾಖಲಾದ ಧ್ವನಿಯನ್ನು ಕೇಳಿ ಅಥವಾ ಮತ್ತೆ ಮಾತನಾಡಿ.';
      return;
    }
    situation.value = text.slice(0, situation.maxLength);
    situation.setCustomValidity('');
    dictated = true;
    voiceStatus.textContent = 'ನಿಮ್ಮ ಮಾತು ಬರಹಕ್ಕೆ ಬದಲಾಗಿದೆ. ಫಲಿತಾಂಶಕ್ಕೆ ಗಾದೆ ಹುಡುಕಿ ಒತ್ತಿರಿ.';
  } catch {
    if (attempt === voiceAttempt) {
      retryVoice.hidden = !lastAudio;
      voiceStatus.textContent = task.signal.aborted ? timeoutMessage : 'ಧ್ವನಿ ಬರಹಕ್ಕೆ ಬದಲಾಗಲಿಲ್ಲ. ದಾಖಲಾದ ಧ್ವನಿಯನ್ನು ಕೇಳಿ, ನಂತರ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';
    }
  } finally {
    clearTimeout(timer);
    if (transcribing === task) {
      transcribing = null;
      updateVoiceControls();
    }
  }
}

retryVoice.addEventListener('click', () => {
  if (lastAudio && !recording && !requested && !transcribing) {
    void acceptAudio(lastAudio.blob, voiceLanguage.value, ++voiceAttempt);
  }
});
voiceFileButton.addEventListener('click', () => voiceFile.click());
voiceFile.addEventListener('change', () => {
  const file = voiceFile.files[0];
  voiceFile.value = '';
  if (!file) return;
  if (file.size > 10 * 1024 * 1024) {
    voiceStatus.textContent = 'ಚಿಕ್ಕ ಧ್ವನಿ ಕಡತವನ್ನು ಆಯ್ಕೆಮಾಡಿ.';
    return;
  }
  resetSearch();
  void acceptAudio(file, voiceLanguage.value, ++voiceAttempt);
});

function blockedMicrophone() {
  const policy = document.permissionsPolicy || document.featurePolicy;
  if (!embedded || policy?.allowsFeature('microphone') !== false) return false;
  voiceStatus.textContent = 'ಮೈಕ್ರೊಫೋನ್ ಬಳಸಲು ಹೊಸ ಟ್ಯಾಬ್‌ನಲ್ಲಿ ತೆರೆಯಿರಿ.';
  standalone.click();
  return true;
}

function startDictation() {
  if (dictation) {
    dictation.finish();
    return;
  }
  if (blockedMicrophone()) return;
  resetSearch();
  const recognition = new SpeechRecognition();
  recognition.lang = voiceLanguage.value;
  recognition.interimResults = true;
  recognition.continuous = false;
  const active = { recognition, text: '', timer: null, limit: null, finishing: false };
  dictation = active;
  updateVoiceControls();
  voiceStatus.textContent = 'ಮೈಕ್ರೊಫೋನ್ ತೆರೆಯಲಾಗುತ್ತಿದೆ…';

  function complete(message) {
    if (dictation !== active) return;
    clearTimeout(active.timer);
    clearTimeout(active.limit);
    dictation = null;
    updateVoiceControls();
    if (active.text) {
      situation.value = active.text.slice(0, situation.maxLength);
      situation.setCustomValidity('');
      dictated = true;
      voiceStatus.textContent = 'ಮಾತು ಬರಹಕ್ಕೆ ಬದಲಾಗಿದೆ. ಈಗ ಗಾದೆ ಹುಡುಕಿ ಒತ್ತಿರಿ.';
    } else {
      voiceStatus.textContent = message;
    }
  }

  active.finish = () => {
    if (active.finishing) return;
    active.finishing = true;
    clearTimeout(active.timer);
    active.timer = setTimeout(() => {
      complete(timeoutMessage);
      recognition.abort();
    }, voiceWait);
    try { recognition.stop(); } catch { complete(timeoutMessage); }
  };
  active.timer = setTimeout(() => {
    complete('ಮೈಕ್ರೊಫೋನ್ ತೆರೆಯಲಿಲ್ಲ. ಅನುಮತಿ ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಒತ್ತಿರಿ.');
    recognition.abort();
  }, voiceWait);
  recognition.onstart = () => {
    if (dictation !== active) return;
    clearTimeout(active.timer);
    if (active.finishing) active.timer = setTimeout(() => {
      complete(timeoutMessage);
      recognition.abort();
    }, voiceWait);
    else voiceStatus.textContent = 'ನಿಮ್ಮ ಸನ್ನಿವೇಶವನ್ನು ಈಗ ಹೇಳಿ…';
  };
  recognition.onresult = event => {
    if (dictation !== active) return;
    active.text = Array.from(event.results, result => result[0].transcript).join(' ').trim();
    if (active.text) situation.value = active.text.slice(0, situation.maxLength);
    if (Array.from(event.results).every(result => result.isFinal)) complete(timeoutMessage);
  };
  recognition.onspeechend = active.finish;
  recognition.onend = () => complete('ಮಾತು ಕೇಳಿಸಲಿಲ್ಲ. ಮತ್ತೆ ಮಾತನಾಡಿ ಅಥವಾ ಧ್ವನಿ ದಾಖಲಿಸಿ.');
  recognition.onerror = event => complete(event.error === 'not-allowed'
    ? 'ಮೈಕ್ರೊಫೋನ್‌ಗೆ ಅನುಮತಿ ನೀಡಿ. ಹೊಸ ಟ್ಯಾಬ್‌ನಲ್ಲಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಬಹುದು.'
    : 'ನೇರ ಧ್ವನಿ ಕೆಲಸ ಮಾಡಲಿಲ್ಲ. ಧ್ವನಿ ದಾಖಲಿಸಿ ಅಥವಾ ಸನ್ನಿವೇಶವನ್ನು ಬರೆಯಿರಿ.');
  active.limit = setTimeout(active.finish, 30000);
  try { recognition.start(); } catch { complete('ಮೈಕ್ರೊಫೋನ್ ತೆರೆಯಲಿಲ್ಲ. ಧ್ವನಿ ದಾಖಲಿಸಿ ಪ್ರಯತ್ನಿಸಿ.'); }
}

async function recordAudio() {
  if (recording) {
    if (recording.recorder.state === 'recording') recording.recorder.stop();
    return;
  }
  if (requested || transcribing) return;
  if (blockedMicrophone()) return;
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder ||
      !(window.AudioContext || window.webkitAudioContext) ||
      !(window.OfflineAudioContext || window.webkitOfflineAudioContext)) {
    voiceStatus.textContent = 'ಈ ಬ್ರೌಸರ್‌ನಲ್ಲಿ ಧ್ವನಿ ದಾಖಲಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ. ಸನ್ನಿವೇಶವನ್ನು ಬರೆಯಿರಿ ಅಥವಾ ಬೇರೆ ಬ್ರೌಸರ್‌ನಲ್ಲಿ ತೆರೆಯಿರಿ.';
    return;
  }
  resetSearch();
  const attempt = ++voiceAttempt;
  const language = voiceLanguage.value;
  requested = true;
  updateVoiceControls();
  voiceStatus.textContent = 'ಮೈಕ್ರೊಫೋನ್ ತೆರೆಯಲಾಗುತ್ತಿದೆ…';
  let stream;
  const permissionTimer = setTimeout(() => {
    if (attempt !== voiceAttempt || !requested) return;
    stopRecording();
    voiceStatus.textContent = 'ಮೈಕ್ರೊಫೋನ್‌ಗೆ ಅನುಮತಿ ನೀಡಿ, ನಂತರ ಮತ್ತೆ ಒತ್ತಿರಿ.';
  }, voiceWait);
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    clearTimeout(permissionTimer);
    if (attempt !== voiceAttempt) {
      stream.getTracks().forEach(track => track.stop());
      return;
    }
    const recorder = new MediaRecorder(stream);
    const chunks = [];
    const session = { recorder, stream, timer: null };
    recording = session;
    requested = false;
    recorder.ondataavailable = event => {
      if (event.data.size) chunks.push(event.data);
    };
    recorder.onerror = () => {
      if (recording !== session) return;
      stopRecording();
      voiceStatus.textContent = 'ಧ್ವನಿ ದಾಖಲಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';
    };
    recorder.onstop = async () => {
      releaseRecording(session);
      if (recording !== session) return;
      recording = null;
      await acceptAudio(new Blob(chunks, { type: recorder.mimeType }), language, attempt);
    };
    recorder.start();
    monitorRecording(session);
    session.timer = setTimeout(() => {
      if (recording === session && recorder.state === 'recording') recorder.stop();
    }, 30000);
    voiceStatus.textContent = 'ಈಗ ನಿಮ್ಮ ಸನ್ನಿವೇಶವನ್ನು ಹೇಳಿ. ಮಾತು ಮುಗಿದ ಮೇಲೆ ಮೈಕ್ರೊಫೋನ್ ಗುಂಡಿಯನ್ನು ಮತ್ತೆ ಒತ್ತಿರಿ.';
    updateVoiceControls();
  } catch (error) {
    clearTimeout(permissionTimer);
    stream?.getTracks().forEach(track => track.stop());
    if (attempt !== voiceAttempt) return;
    stopRecording();
    voiceStatus.textContent = ['NotAllowedError', 'SecurityError'].includes(error.name)
      ? 'ಮೈಕ್ರೊಫೋನ್‌ಗೆ ಅನುಮತಿ ನೀಡಿ. ಇಲ್ಲಿ ಅನುಮತಿ ಸಿಗದಿದ್ದರೆ ಹೊಸ ಟ್ಯಾಬ್‌ನಲ್ಲಿ ತೆರೆಯಿರಿ.'
      : 'ಮೈಕ್ರೊಫೋನ್ ಸಿಗಲಿಲ್ಲ. ಸಾಧನದ ಮೈಕ್ರೊಫೋನ್ ಪರಿಶೀಲಿಸಿ ಅಥವಾ ಸನ್ನಿವೇಶವನ್ನು ಬರೆಯಿರಿ.';
  }
}
microphone.addEventListener('click', SpeechRecognition ? startDictation : recordAudio);
recordButton.addEventListener('click', recordAudio);

window.addEventListener('pagehide', event => {
  stopRecording();
  if (lastAudio && !event.persisted) URL.revokeObjectURL(lastAudio.url);
});

function speak(text, feedback) {
  const synth = window.speechSynthesis;
  if (!synth || !window.SpeechSynthesisUtterance) {
    feedback.textContent = 'ಈ ಬ್ರೌಸರ್‌ನಲ್ಲಿ ಗಾದೆಯನ್ನು ಧ್ವನಿಯಲ್ಲಿ ಕೇಳಲು ಸಾಧ್ಯವಿಲ್ಲ.';
    return;
  }
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'kn-IN';
  utterance.rate = 0.88;
  const voice = synth.getVoices().find(item => /^kn(?:[-_]|$)/i.test(item.lang));
  if (voice) utterance.voice = voice;
  utterance.onerror = event => {
    if (event.error === 'canceled' || event.error === 'interrupted') return;
    feedback.textContent = 'ಕನ್ನಡ ಧ್ವನಿ ಲಭ್ಯವಾಗಲಿಲ್ಲ. ಸಾಧನದ ಧ್ವನಿ ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ಪರಿಶೀಲಿಸಿ.';
  };
  feedback.textContent = '';
  synth.cancel();
  synth.speak(utterance);
}

function playback(result) {
  const button = add(matches, 'button', '🔊 ಗಾದೆ ಕೇಳಿ', 'voice-button playback');
  button.type = 'button';
  const feedback = add(matches, 'p', '', 'voice-status');
  feedback.setAttribute('role', 'status');
  const audio = add(matches, 'audio', '', 'proverb-player');
  audio.controls = true;
  audio.preload = 'none';
  audio.setAttribute('aria-label', 'ಗಾದೆಯ ಧ್ವನಿ');
  audio.src = '/audio/' + encodeURIComponent(result.id) + '.mp3';
  audio.addEventListener('play', () => {
    if (playing && playing !== audio) playing.pause();
    playing = audio;
    feedback.textContent = '';
    window.speechSynthesis?.cancel();
  });
  audio.addEventListener('error', () => {
    feedback.textContent = 'ಗಾದೆಯ ಧ್ವನಿ ತೆರೆಯಲಿಲ್ಲ. ಸಂಪರ್ಕವನ್ನು ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಒತ್ತಿರಿ.';
  });
  audio.addEventListener('ended', () => {
    if (playing !== audio) return;
    const kannadaVoice = window.speechSynthesis?.getVoices().some(voice => /^kn(?:[-_]|$)/i.test(voice.lang));
    if (kannadaVoice) speak(['ಗಾದೆಯ ಅರ್ಥ.', result.meaning, result.explanation].filter(Boolean).join(' '), feedback);
  });
  async function play() {
    if (audio.error) audio.load();
    if (audio.readyState) audio.currentTime = 0;
    try {
      await audio.play();
    } catch {
      if (!audio.error) feedback.textContent = 'ಧ್ವನಿ ಕೇಳಲು ಪ್ಲೇ ಗುಂಡಿಯನ್ನು ಒತ್ತಿರಿ.';
    }
  }
  button.addEventListener('click', play);
  return play;
}

function add(parent, name, value, className) {
  const node = document.createElement(name);
  node.textContent = value;
  if (className) node.className = className;
  parent.append(node);
  return node;
}

function card(result, container) {
  const article = document.createElement('article');
  add(article, 'h3', '“' + result.proverb + '”', 'quote');
  const details = add(article, 'dl', '', 'details');
  add(details, 'dt', 'ಗಾದೆಯ ಅರ್ಥ');
  add(details, 'dd', result.meaning);
  if (result.meaningEn) {
    add(details, 'dt', 'English meaning').lang = 'en';
    add(details, 'dd', result.meaningEn).lang = 'en';
  }
  if (result.explanation) {
    add(details, 'dt', 'ಈ ಸನ್ನಿವೇಶಕ್ಕೆ ಗಾದೆ ಹೇಗೆ ಹೊಂದುತ್ತದೆ?');
    add(details, 'dd', result.explanation);
  }
  container.append(article);
}

let activeSearch = null;
function resetSearch() {
  playing?.pause();
  playing = null;
  window.speechSynthesis?.cancel();
  activeSearch?.abort();
  activeSearch = null;
  situation.setCustomValidity('');
  submit.disabled = false;
  matches.replaceChildren();
  heading.hidden = true;
  status.textContent = '';
}

situation.addEventListener('input', () => {
  stopRecording();
  dictated = false;
  voiceStatus.textContent = '';
  resetSearch();
});
form.addEventListener('invalid', () => {
  if (!situation.value.trim()) situation.setCustomValidity('ದಯವಿಟ್ಟು ನಿಮ್ಮ ಸನ್ನಿವೇಶವನ್ನು ಬರೆಯಿರಿ.');
}, true);
form.addEventListener('submit', event => event.preventDefault());
submit.addEventListener('click', async () => {
  if (submit.disabled) return;
  if (dictation) {
    dictation.finish();
    voiceStatus.textContent = 'ಮಾತು ಮುಗಿದ ಬಳಿಕ ಮತ್ತೆ ಗಾದೆ ಹುಡುಕಿ ಒತ್ತಿರಿ.';
    return;
  }
  if (recording || requested || transcribing) {
    voiceStatus.textContent = recording ? 'ಮೊದಲು ಧ್ವನಿ ದಾಖಲಿಸುವುದನ್ನು ಮುಗಿಸಿ.' : 'ಧ್ವನಿ ಸಿದ್ಧವಾಗುವವರೆಗೆ ಕಾಯಿರಿ.';
    return;
  }
  const value = situation.value.trim();
  if (!value) {
    situation.setCustomValidity('ದಯವಿಟ್ಟು ನಿಮ್ಮ ಸನ್ನಿವೇಶವನ್ನು ಬರೆಯಿರಿ.');
    situation.reportValidity();
    return;
  }
  stopRecording();
  const readAloud = dictated;
  const search = new AbortController();
  activeSearch = search;
  submit.disabled = true;
  matches.replaceChildren();
  heading.hidden = true;
  status.textContent = 'ಗಾದೆಯನ್ನು ಹುಡುಕಲಾಗುತ್ತಿದೆ…';
  try {
    const response = await fetch('/api/search', {
      signal: search.signal, method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ situation: value })
    });
    if (!response.ok) throw new Error();
    const { results } = await response.json();
    if (activeSearch !== search) return;
    status.textContent = results.length ? '' : 'ಸಂಗ್ರಹದಲ್ಲಿ ಹೊಂದುವ ಗಾದೆ ಸಿಗಲಿಲ್ಲ. ಏನಾಯಿತು, ಅದಕ್ಕೆ ಕಾರಣವೇನು ಎಂಬುದನ್ನು ಇನ್ನಷ್ಟು ವಿವರಿಸಿ.';
    if (results.length) {
      card(results[0], matches);
      const read = playback(results[0]);
      if (readAloud) read();
      heading.hidden = false;
      heading.focus();
    } else {
      status.scrollIntoView({ block: 'nearest' });
      if (readAloud) speak(status.textContent, voiceStatus);
    }
  } catch {
    if (activeSearch === search) status.textContent = 'ಹುಡುಕಾಟ ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';
  } finally {
    if (activeSearch === search) {
      activeSearch = null;
      submit.disabled = false;
    }
  }
});

for (const sample of document.querySelectorAll('.sample')) {
  sample.addEventListener('click', () => {
    stopRecording();
    dictated = false;
    voiceStatus.textContent = '';
    situation.value = sample.dataset.situation;
    resetSearch();
    situation.focus();
  });
}
const catalogFilter = document.querySelector('#catalog-filter');
const catalogCount = document.querySelector('#catalog-count');
let catalogLoading = false;
const catalogSearch = document.querySelector('#catalog-search');
let catalogEntries = null;
function filterCatalog() {
  if (!catalogEntries) return;
  const filter = catalogFilter.value.trim().normalize('NFC').toLowerCase();
  const filtered = catalogEntries.filter(entry => [entry.proverb, entry.meaning, entry.meaningEn ?? ''].some(text => text.toLowerCase().includes(filter)));
  catalogCount.textContent = new Intl.NumberFormat('kn-IN-u-nu-knda').format(filtered.length) + ' ಗಾದೆಗಳು';
  collection.replaceChildren();
  for (const entry of filtered) card(entry, collection);
  if (!filtered.length) collection.textContent = 'ಈ ಪದಗಳಿಗೆ ಹೊಂದುವ ಗಾದೆ ಸಿಗಲಿಲ್ಲ.';
}
catalogFilter.addEventListener('input', filterCatalog);
async function loadCatalog() {
  if (catalogLoading || catalogEntries) return;
  catalogLoading = true;
  collection.textContent = 'ಗಾದೆಗಳನ್ನು ತರಲಾಗುತ್ತಿದೆ…';
  try {
    const response = await fetch('/api/catalog');
    if (!response.ok) throw new Error();
    catalogEntries = await response.json();
    catalogCount.hidden = false;
    catalogSearch.hidden = false;
    filterCatalog();

  } catch {
    collection.textContent = 'ಸಂಗ್ರಹ ತೆರೆಯಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';
  } finally {
    catalogLoading = false;
  }
}

document.querySelector('#catalog-link').addEventListener('click', () => {
  catalog.open = true;
  void loadCatalog();
});
document.querySelector('#catalog-summary').addEventListener('click', () => {
  if (!catalog.open) void loadCatalog();
});
</script>
</body></html>`;
