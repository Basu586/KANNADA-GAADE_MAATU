# Kannada proverb collection | blank consent template

Use the organizers' approved form if they provide one. Explain the project and read the form aloud in the contributor's preferred language before signing.

- Contributor code:
- Team code:
- Date:
- Region or dialect (optional):
- Collection types agreed to (oral proverb, written proverb, voice recording):
- Agreed public credit (for example, contributor code or agreed name):
- Collector's contact or organizer-approved withdrawal channel:

I understand that my proverbs, examples, and recordings may be reviewed in the project and demonstrated in its app. I have been told what the team plans to share publicly. I understand that a CC BY 4.0 public release allows reuse with attribution, and that copies already released may be redistributed.

- I agree to collection and project review: Yes / No
- I agree to showing my contribution in the public app: Yes / No
- I agree to sharing the selected materials under CC BY 4.0: Yes / No
- Contributor signature or approved mark:
- Collector or witness signature:

Store signed forms privately. Use only the contributor code and consent reference in team metadata.
