import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import original from '../corpus.mjs';
import additional from '../additional-corpus.mjs';
import english from '../english-meanings.mjs';
import csvSituations from '../additional-situations.mjs';
import pdfSituations from '../situation-examples.mjs';
import draftSituations from '../rubric-situations.mjs';
import recordings from '../proverb-audio.mjs';

const location = process.argv[2];
if (!location) throw new Error('Usage: node submission/export.mjs /path/to/team_XX/problem_02');
const output = path.resolve(location);
const audioDir = path.join(output, 'audio');
await mkdir(audioDir, { recursive: true });

function csv(columns, rows) {
  return [columns, ...rows].map(row => row.map(value =>
    '"' + String(value ?? '').replaceAll('"', '""') + '"'
  ).join(',')).join('\n') + '\n';
}

const topicRules = [
  ['money', /money|income|wealth|debt|savings|price|profit|earn|spend|budget|cost|supply|financial/],
  ['study', /education|learn|reading|knowledge|school|teach|study/],
  ['family', /child|parent|home|household|family|spouse|neighbor|hospitality/],
  ['friends', /friend|company|hostility/],
  ['work', /work|task|effort|achievement|leader|opportunit|plan|preparation|responsibilit/]
];

const proverbs = [];
const situations = [];
const metadata = [];
for (const entry of [...original, ...additional]) {
  const { id, proverb, meaning, example, scenario } = entry;
  const audio = 'audio/' + id + '.wav';
  const source = id === 'P236' ? 'challenge_slide' : id.startsWith('KP') ? 'review_csv_100' : 'review_csv_270';
  const theme = topicRules.find(([, rule]) => rule.test(english[id].toLowerCase()))?.[0] ?? 'character';
  proverbs.push([id, proverb, meaning, english[id], example, '', theme, source, audio, 'pending']);
  metadata.push([id, audio, 'kn', 16000, 1, proverb, source, '', '', '', 'true', 'pending']);
  const variants = new Map();
  function include(text, provenance, synthetic) {
    const key = text.normalize('NFC').trim();
    if (!variants.has(key)) variants.set(key, { provenance, synthetic });
  }
  for (const text of csvSituations[id] ?? []) include(text, 'review_csv_270', 'true');
  for (const text of pdfSituations[id] ?? []) include(text, 'user_pdf_ocr_edited', 'unknown');
  for (const text of draftSituations[id] ?? []) include(text, 'project_draft', 'true');
  include(scenario, source, 'unknown');
  include(example, source === 'review_csv_100' && example !== scenario ? 'project_draft' : source, 'unknown');
  if (variants.size < 2) throw new Error('Fewer than two situations for ' + id);
  let index = 0;
  for (const [text, { provenance, synthetic }] of variants) {
    situations.push([id + '_S' + ++index, id, text, 'kn', provenance, synthetic, 'pending']);
  }

  if (!recordings[id]) throw new Error('Missing demo audio for ' + id);
  const conversion = spawnSync('ffmpeg', [
    '-v', 'error', '-y', '-i', 'pipe:0', '-ac', '1', '-ar', '16000',
    '-c:a', 'pcm_s16le', path.join(output, audio)
  ], { input: Buffer.from(recordings[id], 'base64') });
  if (conversion.status !== 0) throw new Error(conversion.error?.message || conversion.stderr.toString());
}

await Promise.all([
  writeFile(path.join(output, 'gaade.csv'), csv(
    ['gaade_id', 'gaade', 'meaning', 'english', 'example', 'region', 'theme', 'source', 'audio_file', 'review_status'], proverbs
  )),
  writeFile(path.join(output, 'situations.csv'), csv(
    ['situation_id', 'gaade_id', 'situation', 'language', 'source', 'synthetic', 'review_status'], situations
  )),
  writeFile(path.join(output, 'metadata.csv'), csv(
    ['gaade_id', 'audio_file', 'language', 'sample_rate_hz', 'channels', 'expected_transcript', 'proverb_source', 'contributor_code', 'region', 'consent_reference', 'synthetic', 'review_status'], metadata
  )),
  writeFile(path.join(output, 'README.md'), await readFile(new URL('./README.md', import.meta.url))),
  writeFile(path.join(output, 'consent-template.md'), await readFile(new URL('./consent-template.md', import.meta.url)))
]);
console.log(proverbs.length + ' proverbs, ' + situations.length + ' situations, and ' + metadata.length + ' synthetic WAVs');
