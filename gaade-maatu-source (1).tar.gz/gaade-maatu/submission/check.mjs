import assert from 'node:assert/strict';
import app from '../dist/server/index.js';

const base = 'https://gaade.test';
async function match(situation) {
  const response = await app.fetch(new Request(base + '/api/search', {
    method: 'POST', body: JSON.stringify({ situation })
  }));
  assert.equal(response.status, 200);
  return (await response.json()).results;
}

for (const [situation, id] of [
  ['Ravi skipped studying all term, now panics before the exam.', 'P236'],
  ['Meena earns little but buys a pricey phone on EMI.', 'KP002'],
  ['A neighbour mocks your problems; his house has the same.', 'KP080'],
  ['I never studied and my exam is tomorrow.', 'P236'],
  ['I saved a little money every day until I could buy a bicycle.', 'KP092'],
  ['ಪ್ರವಾಹವನ್ನು ಒಬ್ಬ ವ್ಯಕ್ತಿ ಕೈಯಿಂದ ತಡೆಯಲು ಆಗಲಿಲ್ಲ', 'P139']
]) {
  const results = await match(situation);
  assert.equal(results.length, 1, situation);
  assert.equal(results[0].id, id, situation);
  assert.ok(results[0].meaning && results[0].meaningEn && results[0].explanation);
}
assert.deepEqual(await match('I saw a blue moon tonight.'), []);

const catalog = await (await app.fetch(new Request(base + '/api/catalog'))).json();
assert.equal(catalog.length, 233);
assert.equal(new Set(catalog.map(entry => entry.proverb)).size, catalog.length);
for (const { id } of catalog) {
  const audio = await app.fetch(new Request(base + '/audio/' + id + '.mp3'));
  assert.equal(audio.headers.get('content-type'), 'audio/mpeg');
  assert.ok((await audio.arrayBuffer()).byteLength > 700);
}
console.log('Starter cases, paraphrases, bilingual meanings, catalog, and audio validated.');
