# ಗಾದೆ ಮಾತು | Gaade Kosha prototype and draft dataset

[Live prototype](https://gaadi-maatu-kannada.gableddisco16.chatgpt.site)

## Demo

1. Type or paste a real-life situation in Kannada or English, or choose a microphone language, record, and check the transcript. Use the standalone website for microphone access if the embedded preview blocks it.
2. Press **ಗಾದೆ ಹುಡುಕಿ**. Read the single matching proverb, the Kannada and English meanings, and the Kannada explanation.
3. Press **ಗಾದೆ ಕೇಳಿ** to hear the proverb. Try the three starter situations from the challenge slides and an unfamiliar situation from another team.

The matcher uses phrases, word overlap, and labeled situation examples. Run `npm run build` to build the Cloudflare Worker. Run `node submission/check.mjs` after building to check the starter examples, catalog, audio response, and no-match case.

## Files and provenance

Run `node submission/export.mjs /absolute/path/team_XX/problem_02` with Node.js and FFmpeg installed. Replace `XX` with the assigned team number. The exporter writes UTF-8 CSVs and 16 kHz mono PCM WAV files.

| File | Contents |
| --- | --- |
| `gaade.csv` | Proverb ID, Kannada text and meaning, English meaning, example, region, theme, source, audio file and review status. Themes are provisional. |
| `situations.csv` | Distinct situations labeled with the proverb ID. Authorship and review status are tracked per row. |
| `metadata.csv` | Audio path, expected transcript and format, provenance, synthetic flag and fields for contributor and consent references. |
| `audio/` | Synthetic Kannada readings for demo and format validation. |
| `consent-template.md` | Blank collection template for use with the organizers' approved consent process. |

The proverb list comes from the two uploaded review CSVs and one starter proverb in the challenge brief. Situation sources include the review CSVs, corrected OCR excerpts from the uploaded PDF, and draft situations added for entries with fewer than two. The PDF was used as situation text. Some CSV entries are wording variants or near-synonyms. English text explains the sense of each proverb in English. It may use a plain-language gloss where an idiomatic equivalent is unavailable.

## Readiness and review

The draft meets numerical and WAV-format targets. The challenge requires 200+ proverbs collected from people, 400+ real-life situations, and one human reading per entry. The draft files do not establish those requirements. Region, contributor and consent references are blank because they were not supplied. The readings were generated from the Kannada proverb text with text to speech and are marked synthetic. Verify spoken wording against a Kannada speaker before counting any recording as reviewed.

Before submission, collect or verify the proverbs directly with elders and neighbors. Record each accepted proverb in 16 kHz mono WAV and capture the contributor's region and source code. Replace synthetic recordings and draft situations with verified contributions. Confirm exact text, transcript, pronunciation, clipping, variant spelling, and duplicates, then have a different team review the entries and test the matcher on unfamiliar situations. Record review scores in the team submission. Confirm contributor consent and any third-party rights before a CC BY 4.0 release. Credit contributors in the agreed form. Keep signed forms in the organizer-approved private channel. Keep names, addresses, phone numbers and signatures out of public data. No images are used in this dataset.
