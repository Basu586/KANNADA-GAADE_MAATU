const models = new Map();

function modelFor(language) {
  if (!models.has(language)) {
    const kannada = language === 'kn-IN';
    const model = kannada ? 'astronova001/whisper-kannada-tiny-ONNX' : 'Xenova/whisper-tiny';
    const revision = kannada ? '44410f39a5b7a18a4023293d532f3db01716ce15' : '5332fcc35e32a33b86612b9a57a89be7906102b1';
    const pending = import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.2/dist/transformers.min.js')
      .then(({ env, pipeline }) => {
        env.allowLocalModels = false;
        env.backends.onnx.wasm.numThreads = 1;
        return pipeline('automatic-speech-recognition', model, { device: 'wasm', dtype: 'q8', revision });
      }).catch(error => {
        models.delete(language);
        throw error;
      });
    models.set(language, pending);
  }
  return models.get(language);
}

let queue = Promise.resolve();
self.addEventListener('message', ({ data: { id, language, audio } }) => {
  const ready = modelFor(language);
  ready.catch(() => {});
  queue = queue.then(async () => {
    try {
      const recognize = await ready;
      const options = language === 'kn-IN'
        ? { return_timestamps: false }
        : { language: 'english', task: 'transcribe', return_timestamps: false };
      const result = await recognize(audio, options);
      self.postMessage({ id, text: result.text.trim() });
    } catch {
      self.postMessage({ id, error: true });
    }
  });
});
